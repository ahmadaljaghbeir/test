## Coveralls example application using Codefresh Pipeline

Little tag from our Coveralls integration:

[![Coverage Status](https://coveralls.io/repos/github/anais-codefresh/coveralls-sample-app/badge.svg?branch=master)](https://coveralls.io/github/anais-codefresh/coveralls-sample-app?branch=master)
